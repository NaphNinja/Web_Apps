#!/usr/bin/env python3

import os

xnum1 = int(input("Initiate the first range with: "))
znum1 = int(input("Complete the first range with: "))
first_range = list(range(xnum1, znum1+1))

xnum2 = int(input("Initiate the second range with: "))
znum2 = int(input("Complete the second range with: "))
second_range = list(range(xnum2, znum2+1))

print ("The first range is:", first_range)

print ("The second range is:", second_range)
