#!/usr/bin/env python3

import os

my_range = int(input('Enter a new range: '))
print(list(range(1, my_range+1)))
